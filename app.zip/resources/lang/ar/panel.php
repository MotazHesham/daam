<?php

return [
    'site_title' => 'daam',

];
