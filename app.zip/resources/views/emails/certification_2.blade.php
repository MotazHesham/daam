
<p>Hello {{ $name }} ,</p>

<p>Click this link to download your Certificate From DAAM</p>

<a href="{{ $path }}">Download Certificate</a>